==============================================================================
                         AGENT REGISTRATION DETAILS                           
==============================================================================
Agent Name         : DKM-TEMP-SERVER
Agent ID           : 003
Astra Server       : agents.cynoxglobal.com
Authentication Key : MDAzIERLTS1URU1QLVNFUlZFUiBhbnkgNjRjNDM1ZTI5MGY5ZDI3NjY1MWQ3NWJiNjFhYzU5NzA4Yjk2ODA4YTkyMjY1ZTdmMGU3ZDZjNjNiOWE5YTI2Yw==
==============================================================================

==============================================================================
Astra Security Agent for Windows (v4.14.5) - Standalone Setup Installer
==============================================================================

Package Contents:
  1. Astra-Agent-Setup-v4.14.5.exe  - Standalone GUI & Silent Windows Installer (~8 MB)
  2. README_WINDOWS_EXE.txt         - Quick reference and deployment instructions

------------------------------------------------------------------------------
Features & Fixes in v4.14.5:
------------------------------------------------------------------------------
- 100% Native Astra Branding (ZERO Wazuh traces in Service, UI, or binaries).
- Pre-configured Astra Manager: agents.cynoxglobal.com
- Built-in Auto-Enrollment Engine:
  * Connects to Astra Manager on port 1515.
  * Uses enrollment password: CynoxAgentSecret2026!
  * Generates client.keys automatically during installation.
- UTF-8 No-BOM Configuration:
  * Prevents XML corruption on Windows PowerShell 5.1.
- Automatic Service Recovery:
  * Configures Windows Service "AstraSvc" with auto-restart on failure.
- Modern WPF/XAML Dark-Theme Agent Management GUI:
  * Desktop and Start Menu shortcuts.
  * Real-time monitoring of all 5 internal daemons.
  * Easy server IP and key management.

------------------------------------------------------------------------------
Installation Methods:
------------------------------------------------------------------------------

Method 1: Interactive GUI Setup (Recommended)
  1. Copy "Astra-Agent-Setup-v4.14.5.exe" to the Windows endpoint (VMware / PC).
  2. Right-click and select "Run as administrator".
  3. The Astra Setup wizard will display pre-filled connection details:
     - Manager Host / IP   : agents.cynoxglobal.com
     - Agent Name          : DKM-TEMP-SERVER
     - Enrollment Password : CynoxAgentSecret2026!
     - Auth Key            : MDAzIERLTS1URU1QLVNFUlZFUiBhbnkgNjRjNDM1ZTI5MGY5ZDI3NjY1MWQ3NWJiNjFhYzU5NzA4Yjk2ODA4YTkyMjY1ZTdmMGU3ZDZjNjNiOWE5YTI2Yw==
  4. Click "Next" -> "Install".
  5. The installer will automatically register the agent, create the service,
     and start AstraSvc.
  6. Click "Finish" to open the Astra Security Agent Manager GUI.
  7. Verify status displays PROTECTED (5/5 Online).

Method 2: Silent Installation (Active Directory / Mass Deployment)
  Run from an Administrator Command Prompt or PowerShell:

  Astra-Agent-Setup-v4.14.5.exe /S

------------------------------------------------------------------------------
Agent Management & Verification:
------------------------------------------------------------------------------
- Service Name : AstraSvc (Astra Security Endpoint Agent)
- Status Check : Get-Service AstraSvc  OR  sc query AstraSvc
- Restart      : net stop AstraSvc && net start AstraSvc
- Install Dir  : C:\Program Files (x86)\Astra Security Agent
- Setup Log    : C:\Program Files (x86)\Astra Security Agent\setup.log
- Agent Logs   : C:\Program Files (x86)\Astra Security Agent\ossec.log
==============================================================================
